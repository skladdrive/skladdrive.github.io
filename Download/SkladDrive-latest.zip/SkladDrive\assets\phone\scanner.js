const params = new URLSearchParams(location.search);
const TOKEN = (function () {
  let token = params.get('token') || sessionStorage.getItem('sdToken') || '';
  if (token && params.get('token')) sessionStorage.setItem('sdToken', token);
  return token;
})();
const statusEl = document.getElementById('status');
const barcodeEl = document.getElementById('barcode');
const qtyEl = document.getElementById('qty');
const modeEl = document.getElementById('mode');
const modeSummaryEl = document.getElementById('modeSummary');
const lastActionPanel = document.getElementById('lastActionPanel');
const lastActionTextEl = document.getElementById('lastActionText');
const undoLastActionButton = document.getElementById('undoLastAction');
const candidatePanel = document.getElementById('candidatePanel');
const candidateListEl = document.getElementById('candidateList');
const productPanel = document.getElementById('productPanel');
const productBarcodeEl = document.getElementById('productBarcode');
const productTitleEl = document.getElementById('productTitle');
const productBrandEl = document.getElementById('productBrand');
const productSkuEl = document.getElementById('productSku');
const productOemEl = document.getElementById('productOem');
const productQtyEl = document.getElementById('productQty');
const productBuyEl = document.getElementById('productBuy');
const productSellEl = document.getElementById('productSell');
const productLocationEl = document.getElementById('productLocation');
const productUnitEl = document.getElementById('productUnit');
const productNoteEl = document.getElementById('productNote');
const productExtraEl = document.getElementById('productExtra');
const appMakeEl = document.getElementById('appMake');
const appModelEl = document.getElementById('appModel');
const appYearFromEl = document.getElementById('appYearFrom');
const appYearToEl = document.getElementById('appYearTo');
const appNoteEl = document.getElementById('appNote');
const createProductButton = document.getElementById('createProduct');
const photoEl = document.getElementById('photo');
const commentEl = document.getElementById('comment');
const sendPhotoButton = document.getElementById('sendPhoto');
const photoProgressEl = document.getElementById('photoProgress');
const workPanel = document.getElementById('workPanel');
const workDateEl = document.getElementById('workDate');
const workListEl = document.getElementById('workList');
const workEditor = document.getElementById('workEditor');
const workTimeEl = document.getElementById('workTime');
const workEndTimeEl = document.getElementById('workEndTime');
const workClientEl = document.getElementById('workClient');
const workCarEl = document.getElementById('workCar');
const workModelEl = document.getElementById('workModel');
const workPlateEl = document.getElementById('workPlate');
const workVinEl = document.getElementById('workVin');
const workExecutorEl = document.getElementById('workExecutor');
const workCommentEl = document.getElementById('workComment');
const workLineCategoryEl = document.getElementById('workLineCategory');
const workLineNameEl = document.getElementById('workLineName');
const workLineQtyEl = document.getElementById('workLineQty');
const workLinePriceEl = document.getElementById('workLinePrice');
const workLineExecutorEl = document.getElementById('workLineExecutor');
const workLineCommentEl = document.getElementById('workLineComment');
const workLinesEl = document.getElementById('workLines');
const inventoryPanel = document.getElementById('inventoryPanel');
const inventoryListEl = document.getElementById('inventoryList');
const sendInventoryButton = document.getElementById('sendInventory');
let lastPingOk = null;
let audioContext = null;
let selectedWorkId = 0;
let editingWork = null;
let editingWorkLines = [];
let phoneContextLabel = 'Куда: активная вкладка ПК';
let workNameMeta = {};
const optionTimers = new WeakMap();
let inventoryItems = [];
let lastLocalUndo = null;

function todayIso() {
  const now = new Date();
  const offset = now.getTimezoneOffset() * 60000;
  return new Date(now.getTime() - offset).toISOString().slice(0, 10);
}
workDateEl.value = todayIso();

function showProductForm(barcode, title) {
  const normalizedBarcode = String(barcode || barcodeEl.value || '').trim();
  if (normalizedBarcode !== productBarcodeEl.value.trim()) clearProductForm();
  productBarcodeEl.value = normalizedBarcode;
  productTitleEl.value = title || '';
  productQtyEl.value = qtyEl.value || productQtyEl.value || '1';
  productPanel.classList.remove('hidden');
  productPanel.scrollIntoView({behavior: 'smooth', block: 'start'});
  productTitleEl.focus();
}

function hideProductForm() {
  productPanel.classList.add('hidden');
}

function clearProductForm() {
  productTitleEl.value = '';
  productBrandEl.value = '';
  productSkuEl.value = '';
  productOemEl.value = '';
  productBuyEl.value = '';
  productSellEl.value = '';
  productLocationEl.value = '';
  productUnitEl.value = 'шт.';
  productNoteEl.value = 'Создано с телефона';
  appMakeEl.value = '';
  appModelEl.value = '';
  appYearFromEl.value = '';
  appYearToEl.value = '';
  appNoteEl.value = '';
  productExtraEl.open = false;
}

function setStatus(text, bad) {
  statusEl.textContent = text;
  statusEl.style.color = bad ? '#b42318' : '#334155';
}

function showLastAction(text, bad, undoAvailable) {
  lastActionTextEl.textContent = (bad ? '! ' : '✓ ') + String(text || 'Готово');
  lastActionTextEl.style.color = bad ? '#b42318' : '#334155';
  undoLastActionButton.classList.toggle('hidden', !undoAvailable);
  lastActionPanel.classList.remove('hidden');
}

function updateModeSummary() {
  modeSummaryEl.textContent = phoneContextLabel || 'Куда: активная вкладка ПК';
}

function beep(kind) {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    audioContext = audioContext || new AudioCtx();
    if (audioContext.state === 'suspended') audioContext.resume().catch(() => {});
    const tones = kind === 'photo' ? [[740, 0.07], [980, 0.09]] : kind === 'error' ? [[220, 0.18]] : [[1040, 0.08]];
    tones.forEach((tone, index) => {
      const start = audioContext.currentTime + index * 0.11;
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      osc.type = kind === 'error' ? 'sawtooth' : 'sine';
      osc.frequency.setValueAtTime(tone[0], start);
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.16, start + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + tone[1]);
      osc.connect(gain);
      gain.connect(audioContext.destination);
      osc.start(start);
      osc.stop(start + tone[1] + 0.02);
    });
  } catch (_) {}
}

function reportError(err) {
  setStatus((err && err.message) || 'Ошибка', true);
  beep('error');
}

async function getJson(path) {
  const response = await fetch(path, {
    headers: {'X-SkladDrive-Token': TOKEN},
    cache: 'no-store'
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) throw new Error(data.error || 'Нет связи с ПК');
  return data;
}

async function postJson(path, payload) {
  const response = await fetch(path, {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-SkladDrive-Token': TOKEN},
    body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) throw new Error(data.error || 'Ошибка отправки');
  return data;
}

function applyContext(data) {
  if (data && data.context_label) phoneContextLabel = String(data.context_label);
  updateModeSummary();
}

async function fetchOptions(kind, query = '', parent = '') {
  const path = '/api/options?kind=' + encodeURIComponent(kind)
    + '&q=' + encodeURIComponent(query || '')
    + '&parent=' + encodeURIComponent(parent || '');
  return getJson(path);
}

function fillDatalist(id, items) {
  const list = document.getElementById(id);
  list.innerHTML = '';
  (items || []).forEach(value => {
    const option = document.createElement('option');
    option.value = value;
    list.append(option);
  });
}

function bindOptions(input, listId, kind, parentValue = () => '', onLoaded = null) {
  const load = async () => {
    const data = await fetchOptions(kind, input.value, parentValue());
    fillDatalist(listId, data.items);
    if (onLoaded) onLoaded(data);
  };
  input.addEventListener('focus', () => load().catch(reportError));
  input.addEventListener('input', () => {
    clearTimeout(optionTimers.get(input));
    optionTimers.set(input, setTimeout(() => load().catch(reportError), 180));
  });
  return load;
}

function updateModePanels() {
  const mode = modeEl.value;
  workPanel.classList.toggle('hidden', mode !== 'work');
  inventoryPanel.classList.toggle('hidden', mode !== 'inventory');
  if (mode === 'work') loadWorkList().catch(reportError);
  if (mode === 'inventory') renderInventory();
  updateModeSummary();
}

function parseQty(value) {
  const parsed = Number(String(value || '1').replace(',', '.'));
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
}

function qtyText(value) {
  const num = Number(value || 0);
  return Number.isInteger(num) ? String(num) : String(Math.round(num * 1000) / 1000);
}

function loadInventory() {
  try {
    const saved = JSON.parse(localStorage.getItem('skladdrive_inventory') || '[]');
    inventoryItems = Array.isArray(saved) ? saved.filter(item => item && item.barcode && Number(item.qty) > 0) : [];
  } catch (_) {
    inventoryItems = [];
  }
}

function saveInventory() {
  localStorage.setItem('skladdrive_inventory', JSON.stringify(inventoryItems));
}

function addInventoryLocal(code, qty) {
  const value = String(code || '').trim();
  if (!value) { setStatus('Введите или отсканируйте код', true); return; }
  const existing = inventoryItems.find(item => item.barcode === value);
  if (existing) {
    existing.qty = Number(existing.qty || 0) + qty;
  } else {
    inventoryItems.push({barcode: value, qty});
  }
  saveInventory();
  renderInventory();
  const total = inventoryItems.find(item => item.barcode === value)?.qty || qty;
  const message = 'Инвентаризация: ' + value + ', в строке ' + qtyText(total);
  lastLocalUndo = {barcode: value, qty};
  setStatus(message);
  showLastAction(message, false, true);
  beep('scan');
}

function undoLocalInventory() {
  if (!lastLocalUndo) return false;
  const item = inventoryItems.find(row => row.barcode === lastLocalUndo.barcode);
  if (item) {
    item.qty = Math.max(0, Number(item.qty || 0) - Number(lastLocalUndo.qty || 0));
    if (item.qty <= 0) inventoryItems = inventoryItems.filter(row => row !== item);
  }
  const label = lastLocalUndo.barcode;
  lastLocalUndo = null;
  saveInventory();
  renderInventory();
  const message = 'Отменено: инвентаризация, ' + label;
  setStatus(message);
  showLastAction(message, false, false);
  return true;
}

async function undoLastAction() {
  if (undoLocalInventory()) return;
  const result = await postJson('/api/undo', {});
  setStatus(result.message || 'Последнее добавление отменено');
  showLastAction(result.message || 'Последнее добавление отменено', false, false);
  beep('scan');
}

function renderInventory() {
  inventoryListEl.innerHTML = '';
  if (!inventoryItems.length) {
    inventoryListEl.innerHTML = '<p class="hint">Список пуст. Сканируйте штрихкоды или вводите вручную.</p>';
  } else {
    inventoryItems.forEach(item => {
      const row = document.createElement('div');
      row.className = 'inventory-row';
      row.textContent = item.barcode + ' x' + qtyText(item.qty);
      row.addEventListener('click', () => {
        barcodeEl.value = item.barcode;
        qtyEl.value = qtyText(item.qty);
      });
      inventoryListEl.append(row);
    });
  }
  sendInventoryButton.textContent = inventoryItems.length ? ('Отправить список (' + inventoryItems.length + ')') : 'Отправить список';
}

function clearInventory() {
  inventoryItems = [];
  lastLocalUndo = null;
  saveInventory();
  renderInventory();
  setStatus('Инвентаризация очищена');
}

async function sendInventory(compareAfter) {
  if (!inventoryItems.length) {
    if (compareAfter) return compareInventoryOnly();
    setStatus('Список инвентаризации пуст');
    return null;
  }
  const result = await postJson('/api/inventory/bulk', {items: inventoryItems});
  setStatus(result.message || 'Инвентаризация отправлена');
  lastLocalUndo = null;
  showLastAction(result.message || 'Инвентаризация отправлена', false, false);
  inventoryItems = [];
  saveInventory();
  renderInventory();
  if (compareAfter) return compareInventoryOnly();
  beep('scan');
  return result;
}

function renderWorkList(works) {
  workListEl.innerHTML = '';
  if (!works || !works.length) {
    workListEl.innerHTML = '<p class="hint">На выбранный день работ нет.</p>';
    return;
  }
  works.forEach(work => {
    const row = document.createElement('div');
    row.className = 'work-row' + (work.selected ? ' selected' : '');
    row.addEventListener('click', () => selectWork(work.id));
    const head = document.createElement('div');
    head.className = 'work-head';
    const title = document.createElement('div');
    title.className = 'work-title';
    title.textContent = (work.selected ? '✓ ' : '') + displayWorkLabel(work);
    const editButton = document.createElement('button');
    editButton.type = 'button';
    editButton.className = 'work-edit';
    editButton.textContent = '📝';
    editButton.title = 'Править';
    editButton.addEventListener('click', event => {
      event.stopPropagation();
      toggleWorkEditor(work);
    });
    head.append(title, editButton);
    const meta = document.createElement('div');
    meta.className = 'work-meta';
    meta.textContent = [work.status_label, work.number, work.total_sum ? (work.total_sum + ' руб.') : ''].filter(Boolean).join(' · ');
    row.append(head, meta);
    workListEl.append(row);
  });
}

function displayWorkLabel(work) {
  let label = String(work.label || '').trim();
  if (label.toLowerCase().startsWith('работа ')) label = label.slice('работа '.length).trim();
  if (!label) label = String(work.number || '').trim();
  return label || 'Без названия';
}

async function loadWorkList() {
  const data = await getJson('/api/work?date=' + encodeURIComponent(workDateEl.value || ''));
  selectedWorkId = Number(data.selected_work_id || 0);
  applyContext(data);
  renderWorkList(data.works || []);
  return data;
}

async function selectWork(workId) {
  const result = await postJson('/api/work/select', {work_id: workId});
  selectedWorkId = Number(result.selected_work_id || workId || 0);
  applyContext(result);
  setStatus(result.work ? ('Выбрана ' + displayWorkLabel(result.work)) : (result.message || 'Работа выбрана'));
  await loadWorkList();
}

function hideCandidates() {
  candidatePanel.classList.add('hidden');
  candidateListEl.innerHTML = '';
}

// ПК просит выбрать товар, но список вариантов не пришёл: проверяем и новую
// формулировку («выберите товар»), и старую («выберите на телефоне»).
function asksToChooseProduct(message) {
  const text = String(message || '').toLowerCase();
  return text.indexOf('выберите товар') >= 0 || text.indexOf('выберите на телефоне') >= 0;
}

function showCandidates(candidates, message, candidatesMore, candidateLimit, candidatesTotal) {
  candidateListEl.innerHTML = '';
  const all = candidates || [];
  const limit = Number(candidateLimit) > 0 ? Number(candidateLimit) : (all.length || 30);
  const shown = all.slice(0, limit);
  shown.forEach(candidate => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'candidate-button';
    const title = document.createElement('span');
    title.textContent = candidate.label || candidate.title || candidate.barcode || 'Товар';
    button.append(title);
    if (candidate.details) {
      const details = document.createElement('span');
      details.className = 'candidate-details';
      details.textContent = candidate.details;
      button.append(details);
    }
    button.addEventListener('click', () => selectCandidate(candidate).catch(reportError));
    candidateListEl.append(button);
  });
  const hasMore = candidatesMore || all.length > limit;
  if (hasMore) {
    const moreHint = document.createElement('p');
    moreHint.className = 'hint';
    const total = Number(candidatesTotal) > 0 ? Number(candidatesTotal) : 0;
    moreHint.textContent = total > shown.length
      ? 'Показаны первые ' + shown.length + ' из ' + total + ' — уточните запрос.'
      : 'Показаны первые ' + shown.length + ' — уточните запрос.';
    candidateListEl.append(moreHint);
  }
  candidatePanel.classList.remove('hidden');
  const statusText = message && String(message).trim()
    ? String(message)
    : 'Найдено несколько вариантов — выберите товар ниже';
  setStatus(statusText, true);
  candidatePanel.scrollIntoView({behavior: 'smooth', block: 'start'});
}

async function selectCandidate(candidate) {
  const result = await postJson('/api/scan/candidate', {
    mode: modeEl.value,
    barcode: barcodeEl.value,
    qty: qtyEl.value || 1,
    candidate
  });
  if (!result.warning) {
    hideCandidates();
    hideProductForm();
  }
  setStatus(result.message || 'Товар выбран', result.warning);
  lastLocalUndo = null;
  showLastAction(result.message || 'Товар выбран', result.warning, result.undo_available && !result.warning);
  beep(result.warning ? 'error' : 'scan');
}

function renderWorkLines() {
  workLinesEl.innerHTML = '';
  if (!editingWorkLines.length) {
    workLinesEl.innerHTML = '<p class="hint">Работы пока не добавлены.</p>';
    return;
  }
  editingWorkLines.forEach((line, index) => {
    const row = document.createElement('div');
    row.className = 'work-line';
    const head = document.createElement('div');
    head.className = 'work-line-head';
    const title = document.createElement('div');
    title.className = 'work-line-title';
    title.textContent = line.name || 'Работа';
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'secondary';
    remove.textContent = 'Удалить';
    remove.addEventListener('click', () => {
      editingWorkLines.splice(index, 1);
      renderWorkLines();
    });
    head.append(title, remove);
    const meta = document.createElement('div');
    meta.className = 'work-meta';
    meta.textContent = [line.category, line.executor, 'кол-во ' + qtyText(line.qty || 1), line.price ? ('цена ' + line.price) : '', line.comment]
      .filter(Boolean).join(' · ');
    row.append(head, meta);
    workLinesEl.append(row);
  });
}

function clearWorkLineInputs() {
  workLineCategoryEl.value = '';
  workLineNameEl.value = '';
  workLineQtyEl.value = '1';
  workLinePriceEl.value = '';
  workLineExecutorEl.value = '';
  workLineCommentEl.value = '';
  workNameMeta = {};
}

function addWorkLine() {
  const name = workLineNameEl.value.trim();
  if (!name) { setStatus('Выберите или введите работу', true); return; }
  const details = workNameMeta[name] || {};
  editingWorkLines.push({
    category: workLineCategoryEl.value.trim() || details.category || '',
    work_type: details.work_type || '',
    name,
    executor: workLineExecutorEl.value.trim(),
    qty: parseQty(workLineQtyEl.value),
    price: workLinePriceEl.value.trim() || details.price || '',
    comment: workLineCommentEl.value.trim()
  });
  clearWorkLineInputs();
  renderWorkLines();
  setStatus('Работа добавлена в карточку');
}

function showWorkEditor(work) {
  editingWork = work;
  selectedWorkId = Number(work.id || 0);
  workTimeEl.value = work.work_time || '';
  workEndTimeEl.value = work.end_time || '';
  workClientEl.value = work.client_name || '';
  workCarEl.value = work.car || '';
  workModelEl.value = work.model || '';
  workPlateEl.value = work.plate || '';
  workVinEl.value = work.vin || '';
  workExecutorEl.value = work.executor || '';
  workCommentEl.value = work.comment || '';
  editingWorkLines = Array.isArray(work.works) ? work.works.map(line => ({...line})) : [];
  clearWorkLineInputs();
  renderWorkLines();
  workEditor.classList.remove('hidden');
}

function toggleWorkEditor(work) {
  if (editingWork && Number(editingWork.id || 0) === Number(work.id || 0) && !workEditor.classList.contains('hidden')) {
    workEditor.classList.add('hidden');
    return;
  }
  showWorkEditor(work);
}

async function saveWorkEditor() {
  if (!editingWork || !editingWork.id) { setStatus('Выберите работу', true); return; }
  const result = await postJson('/api/work/update', {
    work_id: editingWork.id,
    fields: {
      work_time: workTimeEl.value,
      end_time: workEndTimeEl.value,
      client_name: workClientEl.value,
      car: workCarEl.value,
      model: workModelEl.value,
      plate: workPlateEl.value,
      vin: workVinEl.value,
      executor: workExecutorEl.value,
      comment: workCommentEl.value,
      works: editingWorkLines
    }
  });
  setStatus(result.message || 'Работа обновлена');
  applyContext(result);
  workEditor.classList.add('hidden');
  await loadWorkList();
}

async function compareInventoryOnly() {
  const result = await postJson('/api/inventory/compare', {});
  setStatus(result.message || 'Сверка готова', result.warning);
  showLastAction(result.message || 'Сверка готова', result.warning, false);
  beep(result.warning ? 'error' : 'scan');
}

async function sendScan(code) {
  const value = String(code || barcodeEl.value || '').trim();
  if (!value) { setStatus('Введите или отсканируйте код', true); return; }
  barcodeEl.value = value;
  if (modeEl.value === 'inventory') {
    addInventoryLocal(value, parseQty(qtyEl.value));
    return;
  }
  const result = await postJson('/api/scan', {mode: modeEl.value, barcode: value, qty: qtyEl.value || 1});
  if (result.candidates && result.candidates.length) {
    showCandidates(result.candidates, result.message, result.candidates_more, result.candidate_limit, result.candidates_total);
    showLastAction(result.message || 'Найдено несколько вариантов — выберите товар ниже', true, false);
    beep('error');
  } else if (asksToChooseProduct(result.message)) {
    hideCandidates();
    const notice = 'ПК попросил выбрать товар, но список вариантов не пришёл. Обновите ПК и мобильный клиент и отправьте скан ещё раз.';
    setStatus(notice, true);
    showLastAction(notice, true, false);
    beep('error');
  } else if (result.can_create_product) {
    hideCandidates();
    showProductForm(result.barcode || value, result.prefill_title || '');
    const notice = modeEl.value === 'work'
      ? 'Деталь не найдена. Ниже открыта форма нового товара.'
      : 'Товар не найден. Ниже открыта форма нового товара.';
    setStatus(notice, true);
    showLastAction(notice, true, false);
    beep('error');
  } else if (!result.warning) {
    hideCandidates();
    setStatus(result.message || ('Отправлено: ' + value), false);
    lastLocalUndo = null;
    showLastAction(result.message || ('Отправлено: ' + value), false, result.undo_available);
    hideProductForm();
    beep('scan');
  } else {
    hideCandidates();
    setStatus(result.message || ('Отправлено: ' + value), true);
    showLastAction(result.message || ('Отправлено: ' + value), true, false);
    beep('error');
  }
}

const loadAppModels = bindOptions(appModelEl, 'appModelOptions', 'car_models', () => appMakeEl.value);
const loadWorkCars = bindOptions(workCarEl, 'workCarOptions', 'car_makes', () => workClientEl.value);
const loadWorkModels = bindOptions(workModelEl, 'workModelOptions', 'car_models', () => workCarEl.value);
const loadWorkNames = bindOptions(
  workLineNameEl,
  'workNameOptions',
  'work_names',
  () => workLineCategoryEl.value,
  data => { workNameMeta = data.meta || {}; }
);
bindOptions(appMakeEl, 'appMakeOptions', 'car_makes');
bindOptions(workClientEl, 'workClientOptions', 'clients');
bindOptions(workExecutorEl, 'workExecutorOptions', 'executors');
bindOptions(workLineExecutorEl, 'workExecutorOptions', 'executors');
bindOptions(workLineCategoryEl, 'workCategoryOptions', 'work_categories');
appMakeEl.addEventListener('change', () => { appModelEl.value = ''; loadAppModels().catch(reportError); });
workClientEl.addEventListener('change', () => { workCarEl.value = ''; workModelEl.value = ''; loadWorkCars().catch(reportError); });
workCarEl.addEventListener('change', () => { workModelEl.value = ''; loadWorkModels().catch(reportError); });
workLineCategoryEl.addEventListener('change', () => { workLineNameEl.value = ''; loadWorkNames().catch(reportError); });
workLineNameEl.addEventListener('change', () => {
  const details = workNameMeta[workLineNameEl.value.trim()] || {};
  if (!workLinePriceEl.value.trim() && details.price) workLinePriceEl.value = details.price;
});

const appBannerEl = document.getElementById('appBanner');
const APP_BANNER_HIDDEN_KEY = 'sdAppBannerHidden';
function setAppBannerHidden(hidden) {
  appBannerEl.classList.toggle('hidden', hidden);
  try {
    if (hidden) localStorage.setItem(APP_BANNER_HIDDEN_KEY, '1');
    else localStorage.removeItem(APP_BANNER_HIDDEN_KEY);
  } catch (error) { /* приватный режим браузера: скрываем только до перезагрузки */ }
}
let bannerHidden = false;
try { bannerHidden = localStorage.getItem(APP_BANNER_HIDDEN_KEY) === '1'; } catch (error) { bannerHidden = false; }
setAppBannerHidden(bannerHidden);
document.getElementById('appBannerClose').addEventListener('click', () => setAppBannerHidden(true));

document.getElementById('send').addEventListener('click', () => sendScan().catch(reportError));
undoLastActionButton.addEventListener('click', () => undoLastAction().catch(reportError));
document.getElementById('clear').addEventListener('click', () => { barcodeEl.value = ''; barcodeEl.focus(); hideCandidates(); setStatus('Готово'); });
barcodeEl.addEventListener('keydown', event => {
  if (event.key === 'Enter') sendScan().catch(reportError);
});
modeEl.addEventListener('change', async () => {
  setStatus('Готово');
  hideCandidates();
  hideProductForm();
  updateModePanels();
  try {
    const result = await postJson('/api/mode', {mode: modeEl.value});
    applyContext(result);
    setStatus(result.message || 'Режим выбран');
  } catch (err) {
    reportError(err);
  }
});
document.getElementById('workRefresh').addEventListener('click', () => loadWorkList().catch(reportError));
workDateEl.addEventListener('change', () => loadWorkList().catch(reportError));
document.getElementById('workLineAdd').addEventListener('click', addWorkLine);
document.getElementById('workSave').addEventListener('click', () => saveWorkEditor().catch(reportError));
document.getElementById('workCancel').addEventListener('click', () => workEditor.classList.add('hidden'));
sendInventoryButton.addEventListener('click', () => sendInventory(false).catch(reportError));
document.getElementById('compareInventory').addEventListener('click', () => sendInventory(true).catch(reportError));
document.getElementById('clearInventory').addEventListener('click', clearInventory);
document.getElementById('hideProduct').addEventListener('click', hideProductForm);
createProductButton.addEventListener('click', async () => {
  createProductButton.disabled = true;
  try {
    const result = await postJson('/api/product', {
      mode: modeEl.value,
      barcode: productBarcodeEl.value || barcodeEl.value,
      title: productTitleEl.value,
      brand: productBrandEl.value,
      sku: productSkuEl.value,
      oem: productOemEl.value,
      qty: productQtyEl.value || qtyEl.value || 0,
      buy_price: productBuyEl.value,
      sell_price: productSellEl.value,
      location: productLocationEl.value,
      unit: productUnitEl.value || 'шт.',
      note: productNoteEl.value || 'Создано с телефона',
      applicability: (appMakeEl.value.trim() || appModelEl.value.trim()) ? [{
        make: appMakeEl.value,
        model: appModelEl.value,
        year_from: appYearFromEl.value,
        year_to: appYearToEl.value,
        note: appNoteEl.value
      }] : []
    });
    setStatus(result.message || 'Товар создан', result.warning);
    lastLocalUndo = null;
    showLastAction(result.message || 'Товар создан', result.warning, result.undo_available && !result.warning);
    if (!result.warning) {
      barcodeEl.value = productBarcodeEl.value || barcodeEl.value;
      clearProductForm();
      hideProductForm();
      beep('photo');
    } else {
      beep('error');
    }
  } catch (err) {
    reportError(err);
  } finally {
    createProductButton.disabled = false;
  }
});

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('Не удалось прочитать фото'));
    reader.readAsDataURL(file);
  });
}

function setPhotoProgress(text, visible = true) {
  photoProgressEl.textContent = text || 'Отправляю фото...';
  photoProgressEl.classList.toggle('hidden', !visible);
}

sendPhotoButton.addEventListener('click', async () => {
  const files = Array.from(photoEl.files || []);
  if (!files.length) { setStatus('Выберите фото', true); return; }
  sendPhotoButton.disabled = true;
  setPhotoProgress('Готовлю фото...');
  try {
    let lastMessage = '';
    for (let index = 0; index < files.length; index += 1) {
      const file = files[index];
      setPhotoProgress('Отправляю фото ' + (index + 1) + '/' + files.length);
      const data = await fileToDataUrl(file);
      const result = await postJson('/api/photo', {
        mode: modeEl.value,
        barcode: barcodeEl.value,
        qty: qtyEl.value || 1,
        name: file.name || 'phone-photo.jpg',
        content_type: file.type || '',
        comment: commentEl.value.trim(),
        data
      });
      lastMessage = result.message || 'Фото сохранено на ПК';
      setStatus('Фото отправлено: ' + (index + 1) + '/' + files.length);
    }
    photoEl.value = '';
    commentEl.value = '';
    setStatus(files.length > 1 ? ('Фото отправлены: ' + files.length) : lastMessage);
    showLastAction(files.length > 1 ? ('Фото отправлены: ' + files.length) : lastMessage, false, false);
    beep('photo');
  } catch (err) {
    reportError(err);
  } finally {
    sendPhotoButton.disabled = false;
    setPhotoProgress('', false);
  }
});

async function pingPc() {
  try {
    const result = await getJson('/api/ping?mode=' + encodeURIComponent(modeEl.value));
    applyContext(result);
    if (lastPingOk === false) setStatus('Связь с ПК восстановлена');
    lastPingOk = true;
  } catch (err) {
    if (lastPingOk !== false) setStatus(err.message || 'Нет связи с ПК', true);
    lastPingOk = false;
  }
}

loadInventory();
renderInventory();
updateModePanels();
setTimeout(pingPc, 400);
setInterval(pingPc, 7000);